USE ad;
DROP TABLE IF EXISTS spatialLocation;